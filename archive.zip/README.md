# ETL_real_state_CABA
ETL project on real state dataset adding gastronomical and subway geographic information to construct a more complete dataset
